package tgs8_a_16;

public interface IGaji {
    
    public float totalGaji();
    
}
