package exception;

public class ExceptionGajiPokok extends Exception{
    public void pesan(){
        System.out.println("[!] Gaji pokok harus lebih besar dari 2.000.000 [!]");
    }
    
}
