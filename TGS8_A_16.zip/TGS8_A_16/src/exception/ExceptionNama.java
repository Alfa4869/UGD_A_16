package exception;

public class ExceptionNama extends Exception{
    public void pesan(){
        System.out.println("[!] Nama tidak boleh Kosong [!]" );
    }
    
}
